﻿// I,Djura Djurickovic 000140392, certify that this material is my
// original work. No other person's work has been used without due
// acknowledgement and I have not made my work available to anyone else.
/*
 Test Data
Player       drily@canada.ca bluebirds
coach         oliviab@rogers.com seasiders
referee       asmith@gmail.com  brewers
Admin         ghouse@gmail.com  cuddy
No Access     akhd@gmail.com             asdas
 
 
 */

using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Services;
using System.Web.Configuration;
using System.Data.SqlClient;

/// <summary>
/// Summary description for WebService
/// </summary>
[WebService(Namespace = "http://lab6.org/")]
[WebServiceBinding(ConformsTo = WsiProfiles.BasicProfile1_1)]
// To allow this Web Service to be called from script, using ASP.NET AJAX, uncomment the following line. 
// [System.Web.Script.Services.ScriptService]
public class HASC_Authentication : System.Web.Services.WebService {

    String role;
    String personID;
    String name;

    public HASC_Authentication () {

        //Uncomment the following line if using designed components 
        //InitializeComponent(); 
    }
    /// <summary>
    /// connects to sql, reads to see isplayer iscoach,isref,isadmin
    /// </summary>
    /// <param name="email">authenticate </param>
    /// <param name="password">String email,password</param>
    /// <returns></returns>
    [WebMethod]
    public bool Authenticate(String email,String password)
    {
        try { 
        SqlConnection connection = new SqlConnection(WebConfigurationManager.ConnectionStrings["HASC"].ConnectionString);
        SqlCommand command = new SqlCommand(
         "SELECT * FROM Persons WHERE Email = @Email AND UserPassword = @UserPassword;",
          connection);

        command.Parameters.AddWithValue("@Email", email);
        command.Parameters.AddWithValue("@UserPassword", password);
        connection.Open();

        //string accessLevel;
        //string personID;
        SqlDataReader reader = command.ExecuteReader();
        // admin, coach, player or referee
        
        if (reader.HasRows)
        {
            reader.Read();

            bool isPlayer = (bool)reader["Player"];
            bool isCoach = (bool)reader["Coach"];
            bool isAdmin = (bool)reader["Administrator"];
            bool isRef = (bool)reader["Referee"];

            personID = reader["PersonID"].ToString();
            name = reader["FirstName"].ToString() + " " + reader["LastName"].ToString(); 

            if (isPlayer) {
                role = "Player";
            }
            else if (isCoach) {
                role = "Coach";
            }
            else if (isAdmin)
            {
                role = "Admin";
            }
            else if (isRef)
            {
                role = "Referee";
            }
            else {
                return false;
            }
        }
        else
        {
            return false;
        }

        reader.Close();

        return true;

        }
        catch/*(Exception e)*/ {
            //e.ToString()
            return false ;   //"Error";
        } 
    }

    /// <summary>
    /// Get role of person
    /// </summary>
    /// <returns>String</returns>
    [WebMethod]
    public String getRole() {
        return role;
    }

    /// <summary>
    /// Get ID of user
    /// </summary>
    /// <returns>Integer</returns>
    [WebMethod]
    public int getID() {
        return int.Parse(personID);
    }

    /// <summary>
    /// Get full name of user
    /// </summary>
    /// <returns>Integer</returns>
    [WebMethod]
    public string getName()
    {
        return name;
    }

}

    
       
 
 
  

       //     SqlDataReader reader = command.ExecuteReader();

       //     if (reader.HasRows)
       //     {

       //         while (reader.Read())
       //         {
       //     reader["DivisionID"];

       //             //update.Parameters["@TeamID"].Value = c;
       //             //update.Parameters["@PlayerID"].Value = reader["PlayerID"];

       //             //update.ExecuteNonQuery();
       //         }
       //     }
       //     else
       //     {
       //         Console.WriteLine("No rows found.");
       //     }
       //     reader.Close();
                                                                       
       //// }