﻿// I,Djura Djurickovic 000140392, certify that this material is my
// original work. No other person's work has been used without due
// acknowledgement and I have not made my work available to anyone else.
/*
 Test Plan 
  
 Player       drily@canada.ca bluebirds
coach         oliviab@rogers.com seasiders
referee       asmith@gmail.com  brewers
Admin         ghouse@gmail.com  cuddy
No Access     akhd@yahoo.ca              asdas
 
 
 
 
 */

using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class _Default : System.Web.UI.Page
{
    /// <summary>
    /// loads page and sets focus to first text box 
    /// </summary>
    /// <param name="sender">pageload</param>
    /// <param name="e">sender,e</param>
    protected void Page_Load(object sender, EventArgs e)
    {
        txtEmail.Focus();
    }
    /// <summary>
    /// authenticates txtemail and txtpassword and if not Authenticate no access. 
    /// </summary>
    /// <param name="sender">btnSubmit</param>
    /// <param name="e">sender,e</param>
    protected void btnSubmit_Click(object sender, EventArgs e)
    {
        try
        {
            HASC_Authentication hascAuth = new HASC_Authentication();

            lblResult.Text = hascAuth.Authenticate(txtEmail.Text, txtPassword.Text);
        }
        catch {
            lblResult.Text = "No Access";
        }

    }
}