﻿//Djura Djurickovic 000140392 , certify that this material is my
// original work. No other person's work has been used without due
// acknowledgement and I have not made my work available to anyone else.

/* Test plan
 * User enter above 255 you should get an error
 * when user hits remember cookie time out 1 min.
 * when data entered datebase updated.  
*/

using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class _Default : System.Web.UI.Page
{
    /// <summary>
    /// checks userSetting if not null then checks lang is not null redirects to default 
    /// </summary>
    /// <param name="sender">page load</param>
    /// <param name="e">sender,e</param>
    protected void Page_Load(object sender, EventArgs e)
    {
        if (Request.Cookies["UserSettings"] != null)
        {
            string lang;
            if (Request.Cookies["UserSettings"]["lang"] != null) {
                lang = Request.Cookies["UserSettings"]["lang"];
                setLanguage(lang);
                redirect();
            }
        }
    }
    /// <summary>
    /// sets the language ES 
    /// </summary>
    /// <param name="sender">imgeButton</param>
    /// <param name="e">sender , e</param>
    protected void ImageButtonES_Click(object sender, ImageClickEventArgs e)
    {
        setLanguage("es");
        redirect();
    }
    /// <summary>
    /// sets the language EN 
    /// </summary>
    /// <param name="sender">imgeButton</param>
    /// <param name="e">sender , e</param>
    protected void ImageButtoEN_Click(object sender, ImageClickEventArgs e)
    {
        setLanguage("en");
        redirect();
    }
    /// <summary>
    /// sets the language FR 
    /// </summary>
    /// <param name="sender">imgeButton</param>
    /// <param name="e">sender , e</param>
    protected void ImageButtonFR_Click(object sender, ImageClickEventArgs e)
    {        
        setLanguage("fr");
        redirect();
    }
    /// <summary>
    /// sees session lang to null  
    /// </summary>
    protected override void InitializeCulture()
    {
        if (Session["lang"] != null)
        {
            base.UICulture = (String)Session["lang"];
        }
        else
        {
            base.InitializeCulture();
        }        
    }
    /// <summary>
    /// cookie check
    /// </summary>
    /// <param name="lang">lang</param>
    private void setLanguage(String lang) {
        Session["lang"] = lang;

        if (Chbxlanguage.Checked)
        {
            Response.Cookies["UserSettings"]["lang"] = lang;
            Response.Cookies["UserSettings"].Expires = DateTime.Now.AddMinutes(1);
        }
    }
    /// <summary>
    /// redirect to game entry.aspx
    /// </summary>
    private void redirect()
    {
        Response.Redirect("game_entry.aspx");
    }
}