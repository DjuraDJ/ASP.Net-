﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.Configuration;
using System.Web.UI;
using System.Web.UI.WebControls;


public partial class game_entry : System.Web.UI.Page
{
    /// <summary>
    /// gameid focus 
    /// h1 around title 
    /// </summary>
    /// <param name="sender">page load</param>
    /// <param name="e">sender,e</param>
    protected void Page_Load(object sender, EventArgs e)
    {
        txtGameId.Focus();
        ltrTitle.Text = "<h1>" + Resources.Site.HASCGameEntry + "</h1>";
    }

    /// <summary>
    /// initialize lang
    /// </summary>
    protected override void InitializeCulture()
    {
        if (Session["lang"] != null)
        {
            base.UICulture = (String)Session["lang"];
        }
        else
        {
            base.InitializeCulture();
        }
    }
    /// <summary>
    /// sets connection
    /// updates datebase with homescore awayscore ect.
    /// </summary>
    /// <param name="sender">btupdate</param>
    /// <param name="e">sender,e</param>
    protected void btnUpdate_Click(object sender, EventArgs e)
    {
        string con_string = WebConfigurationManager.ConnectionStrings["HASCConnectionString"].ConnectionString;
        SqlConnection con = new SqlConnection(con_string);

        SqlCommand cmd = new SqlCommand("UPDATE Games SET HomeTeamScore = @homeScore, AwayTeamScore = @awayScore, GameNotes = @notes WHERE (GameID = @gameID)", con);
        cmd.Parameters.AddWithValue("@homeScore", txtHomeScore.Text);
        cmd.Parameters.AddWithValue("@awayScore",txtAwayScore.Text);
        cmd.Parameters.AddWithValue("@notes", txtNotes.Text);
        cmd.Parameters.AddWithValue("@gameID", txtGameId.Text);

        try
        {
            using (con)
            {
                con.Open();
                int rowsUpdated = cmd.ExecuteNonQuery();

                if (rowsUpdated == 1)
                {
                    lblResultMsg.Text = Resources.Site.Gameupdated;
                    lblResultMsg.ForeColor = System.Drawing.Color.Green;
                }
                else
                {
                    lblResultMsg.Text = Resources.Site.NogameID;
                    lblResultMsg.ForeColor = System.Drawing.Color.Red;
                }
            }

        }
        catch (Exception ex)
        {
            // Label1.Text = ex.ToString();
            lblResultMsg.Text = Resources.Site.sqlError;
            lblResultMsg.ForeColor = System.Drawing.Color.Red;
        }
    }
}