﻿// Djura Djurickovic 000140392, certify that this material is my
  //original work. No other person's work has been used without due
  //acknowledgement and I have not made my work available to anyone else.
    
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Default2 : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    protected void DetailsViewOnePatients_PageIndexChanging(object sender, DetailsViewPageEventArgs e)
    {

    }
    /// <summary>
    /// updates the datebase 
    /// </summary>
    /// <param name="sender">Detail view on patient</param>
    /// <param name="e"></param>
    protected void DetailsViewOnePatients_ItemUpdated(object sender, DetailsViewUpdatedEventArgs e)
    {
        GridViewPatients.DataBind();
    }
}