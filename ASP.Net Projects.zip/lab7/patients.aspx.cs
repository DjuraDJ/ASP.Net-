﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class patients : System.Web.UI.Page
{
    /// <summary>
    /// title of table 
    /// </summary>
    /// <param name="sender">pageLoad</param>
    /// <param name="e">sender,e</param>
    protected void Page_Load(object sender, EventArgs e)
    {
        lblTitle.Text = "Current Patients - " + Request.QueryString["nuid"];    
    }
}