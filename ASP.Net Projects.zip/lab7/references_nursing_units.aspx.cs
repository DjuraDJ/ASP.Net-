﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Web.Configuration;
using System.Data.SqlClient;
using System.Web.UI.DataVisualization.Charting;

public partial class references_nursing_units : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    /// <summary>
    /// nursing unit creates x axis and y axis
    /// 
    /// </summary>
    /// <param name="sender">chart load</param>
    /// <param name="e">e , snder</param>
    protected void Chart1_Load(object sender, EventArgs e)
    {
        string con_string = WebConfigurationManager.ConnectionStrings["CHDBConnectionString"].ConnectionString;
        SqlConnection con = new SqlConnection(con_string);

        SqlCommand cmd = new SqlCommand("SELECT NursingUnits.NursingUnitID NU, COUNT(Admissions.PatientID) AS Patients FROM NursingUnits INNER JOIN Admissions ON NursingUnits.NursingUnitID = Admissions.NursingUnitID WHERE (Admissions.DischargeDate IS NULL) AND (SUBSTRING(NursingUnits.NursingUnitID, 1, 1) = @floor) GROUP BY NursingUnits.NursingUnitID", con);
      
        cmd.Parameters.AddWithValue("@floor", Request.QueryString["floor"]);
        Chart1.Titles.First().Text = "Number of patients on floor "+Request.QueryString["floor"];
        try
        {
            using (con)
            {
                con.Open();
                SqlDataReader reader = cmd.ExecuteReader();

                Chart1.Series["Series1"].Points.DataBindXY(reader, "NU", reader, "Patients");
            }
            foreach (DataPoint p in Chart1.Series["Series1"].Points)
            {
                p.Url = "patients.aspx?nuid=" + p.AxisLabel;
            }
        }
        catch (Exception ex)
        {
           // Label1.Text = ex.ToString();
        }
  
    }
}